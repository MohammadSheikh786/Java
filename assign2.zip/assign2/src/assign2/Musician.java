package assign2;

public class Musician {

    protected static final String drums = "\uD83E\uDD41";
    protected static final String guitar = "\uD83C\uDFB8";
    protected static final String microphone = "\uD83C\uDFA4";

    protected static final int defaultNumberOfKnownSongs = 3;
    protected String name;
    protected Song[] knownSongs;



    public Song[] getKnownSongs() {
        return knownSongs;
    }

    protected int numKnownSongs;


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public int getNumKnownSongs() {
        return numKnownSongs;
    }


    public void setNumKnownSongs(int numKnownSongs) {
        this.numKnownSongs = numKnownSongs;
    }

    public Song getSongAtIndex(int index){
        Song song = null;
        try{
            return knownSongs[index];
        }catch(Exception e){

        }
        return song;
    }

    public Musician(String name, int numOfSongs) {
        this.name = name;
        knownSongs = new Song[numOfSongs];
        numKnownSongs = 0;
    }

    public Musician(String name) {
        this(name, defaultNumberOfKnownSongs);
    }


    public boolean learnSong(Song song) {
        if (numKnownSongs>= knownSongs.length) {
            return false;
        }
        knownSongs[numKnownSongs++] = song;
        return true;
    }

    public void playAllKnownSongs() {
        for (int i=0; i< numKnownSongs; i++) {
            playSong(knownSongs[i]);
        }
    }

    public String toString() {
        return "My name is "+name+" and I know "+numKnownSongs+" song"+(numKnownSongs==1?".":"s.");
    }
    public boolean playSong(Song song) {
        for (int i = 0; i< numKnownSongs; i++) {
            if (song.equals(knownSongs[i])) {
                System.out.println(name + " plays "+song.toString());
                return true;
            }
        }
        System.out.println(name + " does not know "+song.toString());
        return false;
    }

    public static void main(String args[]) {
        System.out.println(drums);
        System.out.println(guitar);
        System.out.println(microphone);

    }
}

