package assign2;

public class Guitarist extends BandMember {

    public Guitarist(String name) {
        super(name);
    }

    public Guitarist(String name, int numOfSongs) {
        super(name, numOfSongs);
    }


    public boolean playSong(Song song) {
        for (int i = 0; i< numKnownSongs; i++) {
            if (song.equals(knownSongs[i])) {
                System.out.println(name + " (guitar) plays (guitar) "+song.toString());
                return true;
            }
        }
        System.out.println(name + " does not know "+song.toString());
        return false;
    }

    public String toString() {
        return "I am the guitarist "+name+" and I know "+numKnownSongs+" song"+(numKnownSongs==1?".":"s.");
    }

}


