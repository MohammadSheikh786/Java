package assign2;

public class Singer extends BandMember {

    public Singer(String name) {
        super(name);
    }

    public Singer(String name, int numOfSongs) {
        super(name, numOfSongs);
    }

    public boolean playSong(Song song) {
        for (int i = 0; i< numKnownSongs; i++) {
            if (song.equals(knownSongs[i])) {
                System.out.println(name + " (microphone) sings (microphone) "+song.toString());
                return true;
            }
        }
        System.out.println(name + " does not know "+song.toString());
        return false;
    }

    public String toString() {
        return "I am the singer "+name+" and I know "+numKnownSongs+" song"+(numKnownSongs==1?".":"s.");
    }
}


