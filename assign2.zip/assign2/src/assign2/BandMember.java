package assign2;

public class BandMember extends Musician {

    public BandMember(String name) {
        super(name);
    }

    public BandMember(String name,int numOfSongs) {
        super(name,numOfSongs);
    }

    boolean knowsSong(Song song){
        boolean flag=false;
        try{
            for (int i=0; i< getNumKnownSongs(); i++) {
                if(song.getName().equalsIgnoreCase(getSongAtIndex(i).getName())){
                    flag=true;
                    return flag;
                }
            }
        }catch(Exception e){}
        return flag;
    }

    boolean canLearnNewSong(Song song){
        if(knowsSong(song) ||numKnownSongs + 1 <= knownSongs.length )
            return true;
        else
            return false;
    }

}

