package assign2;

public class Band extends BandMember {
    private int track;
    private BandMember[] members;

    public Band(String name) {
        super(name);
        track=0;
        members= new BandMember[4];
    }

    public Band(String name,int numOfSongs) {
        super(name,numOfSongs);
        track=0;
        members= new BandMember[4];
    }

    //addMember method
    boolean addMember( BandMember m){
        if(track > 4){
            return false;
        }
        members[track++] = m;
        return true;
    }

    //removeMember code
    boolean removeMember(BandMember m){
        for(int i=0;i<track;i++){
            if(m.getName().equalsIgnoreCase(members[i].getName())){
                for(int j = i; j < members.length - 1; j++){
                    members[j] = members[j+1];
                }
                return true;
            }
        }
        return false;

    }


}