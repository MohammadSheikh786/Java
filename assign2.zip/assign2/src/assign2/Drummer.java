package assign2;

public class Drummer extends BandMember {

    public Drummer(String name) {
        super(name);
    }

    public Drummer(String name, int numOfSongs) {
        super(name, numOfSongs);
    }


    public boolean playSong(Song song) {
        for (int i = 0; i< numKnownSongs; i++) {
            if (song.equals(knownSongs[i])) {
                System.out.println(name + " (drums) plays (drums) "+song.toString());
                return true;
            }
        }
        System.out.println(name + " does not know "+song.toString());
        return false;
    }

    public String toString() {
        return "I am the drummer "+name+" and I know "+numKnownSongs+" song"+(numKnownSongs==1?".":"s.");
    }

}


