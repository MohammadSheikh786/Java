﻿Name: Musa
Student Number : 100935253
Due Date : Sunday, October 13
COMP 1406: Assignment 2


Question 1: "It all works"
My name is Slash and I know 0 songs.

Question 2: "It all works"



Question 3: "It all works"



Question 4: "It all works"



Question 5: "It all works"



Question 6: "It all works"



Question 7: "It all works"




Question 8: "It all works"



Question 9: "It all works"



Question 10: "It all works"



Question 11: "It all works"



Question 12: "It all works"



Question 13: "It all works"

Slash
0
3
Slash (guitar) plays (guitar) the pop song 'unknown'.
Slash (guitar) plays (guitar) the rap song 'Thrash Unreal'.
Slash (guitar) plays (guitar) the rock song 'Black Me Out'.
My name is Axel and I know 1 song.
Axel (microphone) sings (microphone) the pop song 'Little Metal Baby Fist'.
the punk song 'Weird Song'.
the punk song 'Weird Song'.
This song should be printed twice.
Axel does not know the punk song 'Weird Song'.
the pop song 'Baby'.
Baby
pop
false - Should be false.
true - Should be true.
We are GNR playing the song Little Metal Baby Fist! Hit it!
Axel🎤 sings 🎤the rock song 'Little Metal Baby Fist'.
Slash🎸 plays 🎸the rock song 'Little Metal Baby Fist'.
Iforget🥁 plays 🥁the rock song 'Little Metal Baby Fist'.
We are GNR playing the song Thrash Unreal! Hit it!
Axel🎤 sings 🎤the rap song 'Thrash Unreal'.
Slash🎸 plays 🎸the rap song 'Thrash Unreal'.
Iforget🥁 plays 🥁the rap song 'Thrash Unreal'.
