SID # 100935253
Name: Mohammad Sheikh
COMP2804 : Assignment 3
Date: 11/01/2019



Hello welcome to PlayJack Game 

Guide lines to play the game 
-----------------------------

First dealer hand, here you will enter the fill fields manually 2 cards to begin with or press deal card and it will give you the total

Second Player 1 hand,here you will enter  cards to begin with press deal card to get the total 

This will be repeated every turn.

There is also a button place bet to place a bet and new game button is to start over the game and clears up all entries ie. data.  
Then press deal card to start the new game .

Run and compile the BlackJackApplication. All works GUI and functionalities for buttons. No errors.

