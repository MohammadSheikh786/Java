package assign3;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PlayerPane extends HandPane {

    private Label currentBetLabel;
    private TextField currentBetField;

    private Button placeBet;
    private TextField placeBetField;

    public PlayerPane(String name) {
        super(name);

        currentBetLabel = new Label("Current Bet");
        currentBetLabel.relocate(10, 120);
        currentBetLabel.setPrefSize(100, 30);

        placeBet = new Button("Place Bet");

        placeBet.relocate(10, 170);
        placeBet.setPrefSize(100, 30);

        currentBetField = new TextField();

        currentBetField.relocate(140, 120);
        currentBetField.setPrefSize(200, 30);

        placeBetField = new TextField();

        placeBetField.relocate(140, 170);
        placeBetField.setPrefSize(200, 30);

        //Set action on place bet button
        placeBet.setOnAction(event -> {
            currentBetField.setText(placeBetField.getText());
        });

        this.getChildren().addAll(currentBetLabel, placeBet, currentBetField, placeBetField);
    }

    public TextField getCurrentBetField() {
        return currentBetField;
    }

    public TextField getPlaceBetField() {
        return placeBetField;
    }
}
