package assign3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class BlackJackApplication extends Application {

    /*
     These are the 'model' elements.
     */
    Hand dealerHand, playerHand;
    Deck deck;

    HandPane dealer;
    PlayerPane player1;

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("BlackJack!");

        Pane aPane = new Pane();

        //Initialize dealer and player panes
        dealer = new HandPane("Dealer");
        player1 = new PlayerPane("Player 1");
        player1.relocate(0, 100);

        //Initialize hands and deck
        dealerHand = new Hand();
        playerHand = new Hand();
        deck = new Deck();

        //Add deal card button
        Button dealCard = new Button("Deal Card");
        dealCard.relocate(10, 320);
        dealCard.setPrefSize(80, 30);

        //Add new game button
        Button newGame = new Button("New Game");
        newGame.relocate(100, 320);
        newGame.setPrefSize(80, 30);

        //Set action on deal card button to deal the cards to players and update the view
        dealCard.setOnAction(event -> {
            dealerHand.dealCard(deck.dealCard());
            playerHand.dealCard(deck.dealCard());
            update();
        });

        //Set action on new game button to clear the hands and fields
        newGame.setOnAction(event -> {
            dealerHand.newHand();
            playerHand.newHand();

            player1.getCurrentBetField().setText("");
            player1.getPlaceBetField().setText("");

            update();
        });

        //Add components to the pane
        aPane.getChildren().add(dealer);
        aPane.getChildren().add(player1);
        aPane.getChildren().add(dealCard);
        aPane.getChildren().add(newGame);

        //Set hands
        dealer.setHand(dealerHand);
        player1.setHand(playerHand);

        primaryStage.setScene(new Scene(aPane, 400, 400));
        primaryStage.show();
    }

    public void update() {
        //Update GUI on both players
        dealer.setHand(dealerHand);
        player1.setHand(playerHand);
    }

    public static void main(String[] args) {
        launch(args);
    }

}
