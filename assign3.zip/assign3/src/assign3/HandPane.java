package assign3;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class HandPane extends Pane {
    private String name;

    private Label handLabel;
    private TextField handField;

    private Label totalLabel;
    private TextField totalField;

    public HandPane(String name) {
        this.name = name;
        handLabel = new Label(name + " hand");
        handLabel.relocate(10, 20);
        handLabel.setPrefSize(100, 30);

        totalLabel = new Label("Total");

        totalLabel.relocate(10, 70);
        totalLabel.setPrefSize(100, 30);

        handField = new TextField();

        handField.relocate(140, 20);
        handField.setPrefSize(200, 30);

        totalField = new TextField();

        totalField.relocate(140, 70);
        totalField.setPrefSize(200, 30);

        this.getChildren().addAll(handLabel, totalLabel, handField, totalField);
    }

    /**
     * Update UI using the hand
     *
     * @param hand hand of the player
     */
    public void setHand(Hand hand) {
        handField.setText(hand.toString());
        totalField.setText(String.valueOf(hand.getTotal()));
    }

    public TextField getHandField() {
        return handField;
    }

    public TextField getTotalField() {
        return totalField;
    }
}
