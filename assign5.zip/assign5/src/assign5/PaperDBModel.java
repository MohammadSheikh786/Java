package assign5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/*
 * This class takes in a bunch of ResearchPaper objects and organizes and processes them
 * so that they may be displayed.  
 */
public class PaperDBModel {
	
	private HashMap<String, ResearchPaper>            byTitle;  //in essence, the master list of papers. 
																//If the paper exists anywhere in the DB, it will exist here
	private HashMap<String, ArrayList<ResearchPaper>> byAuthor;
	private HashMap<String, ArrayList<ResearchPaper>> byConference;
	private HashMap<String, ArrayList<ResearchPaper>> byKeyword;
	
	public PaperDBModel() {
		//TODO: instantiate all the member variables 
		this.byTitle = new HashMap<String, ResearchPaper>();
		this.byAuthor = new HashMap<String, ArrayList<ResearchPaper>>();
		this.byConference = new HashMap<String, ArrayList<ResearchPaper>>();
		this.byKeyword = new HashMap<String, ArrayList<ResearchPaper>>();
	}
	
	
	public ResearchPaper getResearchPaper(String title) {
		//TODO: finish this method.
		return this.byTitle.get(title);

	}
	
	public ArrayList<ResearchPaper> getPapersByAuthor(String author){
		//TODO: finish this method. 
		return this.byAuthor.get(author);
	}
	
	public ArrayList<ResearchPaper> getPapersByConference(String conference){
		//TODO: finish this method.
		return this.byConference.get(conference);

	}
	
	public ArrayList<ResearchPaper> getPapersByKeyword(String keyword){
		//TODO: finish this method. 
		return this.byKeyword.get(keyword);
	}
	
	/**
	 * Complete this method by putting the new paper in byTitle,
	 * byAuthor, byConference, and byKeyword HashMaps. 
	 * @param paper is the ResearchPaper to add
	 */
	public void addResearchPaper(ResearchPaper paper) {
		//TODO: add this paper in every appropriate Collection
		this.byTitle.put(paper.getTitle(), paper);
//Add By Author
		for(int i=0; i<paper.getAuthors().size(); i++){
			if(!this.byAuthor.containsKey(paper.getAuthors().get(i))){
				ArrayList newObj = new ArrayList<ResearchPaper>();
				newObj.add(paper);
				this.byAuthor.put(paper.getAuthors().get(i), newObj);
			} else {
				ArrayList exists = this.byAuthor.get(paper.getAuthors().get(i));
				exists.add(paper);
				this.byAuthor.put(paper.getAuthors().get(i), exists);
			}
		}
		//Add By Keywords
		for(int i=0; i<paper.getKeywords().size(); i++){
			if(!this.byKeyword.containsKey(paper.getKeywords().get(i))){
				ArrayList newObj = new ArrayList<ResearchPaper>();
				newObj.add(paper);
				this.byKeyword.put(paper.getKeywords().get(i), newObj);
			} else {
				ArrayList exists = this.byKeyword.get(paper.getKeywords().get(i));
				exists.add(paper);
				this.byKeyword.put(paper.getKeywords().get(i), exists);
			}
		}
		//Add By Conference
		if(!this.byConference.containsKey(paper.getConference())){
			ArrayList newObj = new ArrayList<ResearchPaper>();
			newObj.add(paper);
			this.byConference.put(paper.getConference(), newObj);
		} else {
			ArrayList exists = this.byConference.get(paper.getConference());
			exists.add(paper);
			this.byConference.put(paper.getConference(), exists);
		}
	}

	
	/**
	 * Remove every instance of this paper from the database.
	 * @param paper
	 */
	public void removeResearchPaper(ResearchPaper paper) {
		//TODO: remove this paper from every appropriate Collection
		//Remove By Title
		this.byTitle.remove(paper.getTitle());
		//Remove By Authors
		for(int i=0; i<paper.getAuthors().size(); i++){
			this.byAuthor.remove(paper.getAuthors().get(i));
		}
		//Remove By Authors
		for(int i=0; i<paper.getKeywords().size(); i++){
			this.byKeyword.remove(paper.getKeywords().get(i));
		}
		//Remove By Conference
		this.byConference.remove(paper.getConference());
	}
	
	public ArrayList<ResearchPaper> getPapersByAuthorAndConference(String author, String conference){
		//TODO: Return an ArrayList of all the papers that have the author
		//given and were published in the conference give, 
		//or an empty ArrayList if there are no papers. 
		ArrayList<ResearchPaper> list = new ArrayList<ResearchPaper>();
		list.addAll(this.byAuthor.get(author));
		list.addAll(this.byConference.get(conference));
		return list;
	}


	public ArrayList<ResearchPaper> getPapersByAuthors(String ... authors){
		//TODO: return all papers with ALL the authors listed, or an empty list otherwise.
		//That is, if the authors are "Steve", "Helga", every paper returned should have
		//both authors listed.
		ArrayList<ResearchPaper> list = new ArrayList<ResearchPaper>();
		for(int i=0; i<authors.length; i++){
			list.addAll(this.byAuthor.get(authors[i]));
		}
		return list;
	}


	//generic getter methods
	public HashMap<String, ResearchPaper> getPapersByTitle(){
		return byTitle;
	}
	
	public HashMap<String, ArrayList<ResearchPaper>> getPapersByAuthor(){
		return byAuthor;
	}
	
	public HashMap<String, ArrayList<ResearchPaper>> getPapersByConference(){
		return byConference;
	}
	
	public HashMap<String, ArrayList<ResearchPaper>> getPapersByKeyword(){
		return byKeyword;
	}
	
	
	/**
	 * This will help you test by providing some papers you can load from a file and test
	 * your methods on.
	 * @param args
	 */
	public static void main(String[] args) {
		PaperDBModel model = new PaperDBModel();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader("papers.txt"));
			String line = reader.readLine();
			while (line != null) {
				//this is a comment line or an empty line
				if (line.startsWith("#")||line.trim().length()==0) {
					line = reader.readLine();
					continue;
				}
				
				// if anything is there, we assume it is a well formed
				// record. No error checking is done.
				model.addResearchPaper(getResearchPaper(line, reader));
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//TODO: papers are loaded, write tests
		
		//This simply prints out every paper
		for(ResearchPaper paper: model.byTitle.values()) {
			System.out.println(paper);
		}
		
		//TODO: write more tests if you want
		//for(ResearchPaper paper: model.byAuthor.get("Musa")) {
		//	System.out.println(paper);
		//}
	}
	
	/**
	 * The assumption is that the next line in the reader starts the ResearchPaper record.
	 * First line: title
	 * Second line: authors separated by commas
	 * Third line: keywords separated by commas
	 * Fourth line: conference
	 * @param reader
	 * @return
	 */
	private static ResearchPaper getResearchPaper(String line, BufferedReader reader) throws IOException{
		String title = line.trim();
		String[] authors = reader.readLine().split(",");
		ArrayList<String> auths = new ArrayList<>();
		for (String auth: authors) {
			auths.add(auth.trim());
		}
		String[] keywords = reader.readLine().split(",");
		ArrayList<String> keywordList = new ArrayList<>();
		for (String keyw: keywords) {
			keywordList.add(keyw.trim());
		}
		String conf = reader.readLine().trim();
		
		return new ResearchPaper(title, auths, keywordList, conf);
		
	}	
	
	

}
