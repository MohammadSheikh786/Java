Name: Mohammad Musa Sheikh
ID: 100935253
COMP1406: Assignment 5 

Explanation of output:

			
As you can see each record is of fourlines, first line includes title of paper,
second contain list of all authors,seperated by comma, and first,last name are matching.
third line display keywords for the paper and fourth line contain list of conferences.

There is no blank lines and if you add any bad record it will throw exception. 


When I run my files output is same as expected. Below 
is the output copy paste. All Works!!

Title:      Triangles and Squares: A preschool analysis
Authors:    Bobby, Kelly, Jesse, Peter 
Keywords:   graphs, squares, triangles 
Conference: CCCG

Title:      Useless graphs and how to draw them
Authors:    Cindy, Dave, Brett, Shelly 
Keywords:   drawing, graphs, useless 
Conference: Graph Drawing Conference

Title:      Neural Nets: Say Hi to Our Future Machine Overlords
Authors:    Mark, Luke, Peter, Paul 
Keywords:   apocalypse, borg, end of humanity 
Conference: Skynet conference

Title:      How to survive first year comp sci
Authors:    Jesse, Dave, Julie, Shelly 
Keywords:   procrastinating, java, compsci 
Conference: LATIN






Thanks.