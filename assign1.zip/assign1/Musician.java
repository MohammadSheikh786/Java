package assign1;

public class Musician {


    final int defaultNumberOfKnownSongs = 3;
    public String name;
    public Song[] knownSongs;
    public int numKnownSongs;


    //constructor 1
    public Musician(String name , int numberOfSongs)
    {
        this.name = name;
        knownSongs = new Song[numberOfSongs];
        numKnownSongs =0;
    }

    //constructor 2
    public Musician(String name)
    {
        knownSongs =new Song[defaultNumberOfKnownSongs];
        this.name = name;
        numKnownSongs =0;
    }
    public boolean learnSong(Song song)
    {
        if(numKnownSongs==knownSongs.length)
            return false;
        knownSongs[numKnownSongs]= song;
        numKnownSongs++;
        return true;
    }

    @Override
    public String toString() {
        return "My name is "+name+" and I know "+numKnownSongs+" songs.";
    }
    public boolean playSong(Song song)
    {
        for (int i = 0; i <numKnownSongs ; i++) {
            if(knownSongs[i].equals(song))
            {
                System.out.println(name+ " performs "+song);
                return true;
            }
        }

        System.out.println(name + " does not know "+song);
        return false;
    }

    public void playAllKnownSongs()
    {

        for (int i = 0; i <numKnownSongs ; i++) {
            System.out.println(name +" performs "+knownSongs[i]);
        }
    }
}