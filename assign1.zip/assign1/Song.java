package assign1;


import java.util.Random;


public class Song {

    static final String[] songGenre = {"pop", "rap", "rock", "country"};
    static final String[] songName = {"Black Me Out", "Thrash Unreal", "Little Metal Baby Fist", "Zombie Eyed"};
    public String name;
    public String genre;

    //Constructor 1 no argument
    public Song() {
        name = "unknown";
        genre = "pop";
    }
     //Constructor 2
    public Song(String name) {
        this.name = name;
        genre = "pop";
    }
     //Constructor 3
    public Song(String name, String genre) {
        this.name = name;
        this.genre = genre;
    }

    public static Song randomSong()
    {
        Random random = new Random();
        int songGenreIndex = random.nextInt(songGenre.length-1);
        int songNameIndex = random.nextInt(songName.length-1);
        return new Song(songName[songNameIndex],songGenre[songGenreIndex]);
    }

    @Override
    public String toString() {
        return "the "+genre+" song '"+name+"'.";
    }


    public boolean equals(Song song) {
        return this.name.equals(song.name) && this.genre.equals(song.genre);
    }
}