Name: Mohammad Musa Sheikh
SID # 100935353
COMP1404 : Assignment 4


Goal: To implement a model-view-controller design pattern for the
class called BlackJackModel. It provides all the methods and game state needed to play BlackJack. It handles data and
application logic. To make classes; BlackJackView and BlackJackApplication, act as the
controller, and link all three classes in a proper MVC format, at which point the game should be playable.
To add some Alerts and Dialogs to the game to complete the experience

 
 Style marks: I have made the code easy to read and documented it with comments

 1) Completed and everything works!!

 2) Completed and everything works!!

 3) Completed and everything works!!

 4) Completed and everything works!!

 5) Completed and everything works!!

 6) Completed and everything works!!

 7) Completed and everything works!!

 8) (Bonus) Completed and everything works!!

 9) Completed and everything works!!


  

 



