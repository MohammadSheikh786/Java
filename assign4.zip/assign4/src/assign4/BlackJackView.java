package assign4;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

public class BlackJackView extends Pane {

    HandPane dealerPane;
    PlayerPane playerPane;
    Button hitMe, stay, newGame;
    Label message;
    BlackJackModel model;

    public BlackJackView(BlackJackModel model) {
        this.model = model;
        dealerPane = new HandPane("Dealer Hand");
        playerPane = new PlayerPane("Player Hand");

        newGame = new Button("New Deal");
        hitMe = new Button("Hit Me");
        stay = new Button("Stay");


        message = new Label("Place bets!");

        // you may change this to BorderPane if you like.
        // Either way, add the components to it.
        GridPane root = new GridPane();
        root.add(dealerPane, 0, 0);
        root.add(playerPane, 0, 1);

        FlowPane bottomPane = new FlowPane(10, 10);
        bottomPane.getChildren().add(newGame);
        bottomPane.getChildren().add(hitMe);
        bottomPane.getChildren().add(stay);
        bottomPane.getChildren().add(message);

        root.add(new Label(), 0, 3);
        root.add(bottomPane, 0, 4);
        getChildren().add(root);
    }

    public Button getNewGame() {
        return newGame;
    }

    public Button getHitMe() {
        return hitMe;
    }

    public Button getStay() {
        return stay;
    }

    public Button getBetButton() {
        return playerPane.getBetButton();
    }

    public int getBet() {
        return playerPane.getBet();
    }

    // we update all fields in the view with data from the model
    public void update() {
        // All of this information is available by calling the appropriate model method.
        playerPane.setHand(model.getPlayerHand());
        playerPane.setBet(model.getCurrentBet());
        playerPane.setCash(model.getPlayerCash());
        dealerPane.setHand(model.getDealerHand());
        message.setText(model.getMessage());
    }

}
