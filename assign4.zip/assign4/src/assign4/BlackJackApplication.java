package assign4;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

import java.util.Optional;

public class BlackJackApplication extends Application {

    //UI elements
    BlackJackModel model;
    BlackJackView view;

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("BlackJack!");

        //instantiate the model and view here
        model = new BlackJackModel();
        view = new BlackJackView(model);

        //set actions for the buttons
        view.getNewGame().setOnAction(event -> newDeal());
        view.getHitMe().setOnAction(event -> hitMe());
        view.getStay().setOnAction(event -> stay());
        view.getBetButton().setOnAction(event -> playerBets());


        primaryStage.setScene(new Scene(view, 450, 400));
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

    /**
     * helper method to place bets
     */
    private void playerBets() {
        if (model.canBet()) {
            //show the input dialog box
            TextInputDialog td = new TextInputDialog("Bet");
            td.setTitle("Place Bet");
            td.setHeaderText("Enter Bet Amount:");
            Optional<String> result = td.showAndWait();

            result.ifPresent(bet -> {
                model.placeBet(Integer.parseInt(td.getEditor().getText()));
                view.update();
            });
        }
    }

    /**
     * helper method for new deal
     */
    private void newDeal() {
        model.newDeal();
        view.update();
    }

    /**
     * helper method for hit me
     */
    private void hitMe() {
        if (model.canHit()) {
            model.hitMe();
            view.update();
            if (model.playerBusted()) {
                new Alert(Alert.AlertType.INFORMATION, model.getMessage()).show();
            }
        }
    }

    /**
     * helper method for stay
     */
    private void stay() {
        if (model.canStay()) {
            model.stay();
            view.update();
            new Alert(Alert.AlertType.INFORMATION, model.getMessage()).show();
        }
    }


}
